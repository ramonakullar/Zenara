import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Calendar, Search, Star, MapPin, Users, Clock, Shield, CheckCircle2 } from "lucide-react"
import { useState } from "react"

const mediators = [
  {
    id: 1,
    name: "Dr. Sarah Chen",
    specialty: "Family & Divorce",
    location: "Toronto, ON",
    rating: 4.9,
    reviews: 127,
    experience: "15+ years",
    image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
    hourlyRate: 180,
    languages: ["English", "Mandarin"],
    verified: true
  },
  {
    id: 2,
    name: "Michael Rodriguez",
    specialty: "Business & Commercial",
    location: "Vancouver, BC",
    rating: 4.8,
    reviews: 89,
    experience: "12+ years",
    image: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
    hourlyRate: 220,
    languages: ["English", "Spanish"],
    verified: true
  },
  {
    id: 3,
    name: "Emma Thompson",
    specialty: "Workplace & Employment",
    location: "Calgary, AB",
    rating: 4.9,
    reviews: 156,
    experience: "18+ years",
    image: "https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
    hourlyRate: 195,
    languages: ["English", "French"],
    verified: true
  },
  {
    id: 4,
    name: "Dr. James Wilson",
    specialty: "Real Estate & Property",
    location: "Montreal, QC",
    rating: 4.7,
    reviews: 92,
    experience: "10+ years",
    image: "https://images.pexels.com/photos/1559486/pexels-photo-1559486.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
    hourlyRate: 165,
    languages: ["English", "French"],
    verified: true
  },
  {
    id: 5,
    name: "Priya Patel",
    specialty: "International & Cross-Border",
    location: "Toronto, ON",
    rating: 4.8,
    reviews: 73,
    experience: "14+ years",
    image: "https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
    hourlyRate: 210,
    languages: ["English", "Hindi", "Gujarati"],
    verified: true
  },
  {
    id: 6,
    name: "David Kim",
    specialty: "Technology & IP Disputes",
    location: "Ottawa, ON",
    rating: 4.9,
    reviews: 104,
    experience: "11+ years",
    image: "https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
    hourlyRate: 240,
    languages: ["English", "Korean"],
    verified: true
  }
]

export default function ZenaraMVP() {
  const [searchQuery, setSearchQuery] = useState("")
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)

  const filteredMediators = mediators.filter(mediator =>
    mediator.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mediator.specialty.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mediator.location.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-white">
        <div className="max-w-7xl mx-auto px-6 py-24 text-center">
          <div className="space-y-8">
            <h1 className="text-6xl md:text-8xl font-bold text-black tracking-tight">
              Zenara
            </h1>
            <div className="w-32 h-1 bg-yellow-600 mx-auto"></div>
            <p className="text-2xl md:text-3xl text-black font-light max-w-3xl mx-auto leading-relaxed">
              Balanced Resolutions. Global Impact.
            </p>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Connect with certified mediators worldwide for professional dispute resolution
            </p>
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 pt-12 border-t border-gray-200">
              <div className="text-center">
                <div className="text-4xl font-bold text-yellow-600">500+</div>
                <div className="text-sm text-gray-600 mt-2">Certified Mediators</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-black">10,000+</div>
                <div className="text-sm text-gray-600 mt-2">Cases Resolved</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-yellow-600">98%</div>
                <div className="text-sm text-gray-600 mt-2">Success Rate</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-black">24/7</div>
                <div className="text-sm text-gray-600 mt-2">Support Available</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="max-w-4xl mx-auto px-6 mb-20">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input 
            placeholder="Search mediators by specialty, location, or language"
            className="pl-12 h-16 text-lg border-2 border-gray-200 focus:border-yellow-600 rounded-none shadow-none bg-white"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        {/* Quick Filter Tags */}
        <div className="flex flex-wrap gap-3 mt-6 justify-center">
          {["Family", "Business", "Real Estate", "Employment", "International"].map((filter) => (
            <Button 
              key={filter} 
              variant="outline" 
              size="sm"
              className="rounded-none border-2 border-black text-black hover:bg-yellow-600 hover:text-white hover:border-yellow-600 transition-all duration-300 font-medium"
              onClick={() => setSearchQuery(filter.toLowerCase())}
            >
              {filter}
            </Button>
          ))}
        </div>
      </section>

      {/* Mediators Grid */}
      <section className="max-w-7xl mx-auto px-6 mb-24">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-black mb-4">Featured Mediators</h2>
          <div className="w-24 h-1 bg-yellow-600 mx-auto mb-6"></div>
          <p className="text-lg text-gray-600">Discover experienced professionals ready to help resolve your disputes</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {filteredMediators.map((mediator) => (
            <Card 
              key={mediator.id} 
              className={`group cursor-pointer transition-all duration-300 hover:shadow-xl border-2 border-gray-200 rounded-none overflow-hidden bg-white ${
                hoveredCard === mediator.id ? 'border-yellow-600 shadow-xl' : ''
              }`}
              onMouseEnter={() => setHoveredCard(mediator.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <CardContent className="p-0">
                {/* Profile Header */}
                <div className="relative p-8 bg-gray-50">
                  <div className="flex items-start justify-between mb-6">
                    <div className="relative">
                      <img
                        src={mediator.image}
                        alt={mediator.name}
                        className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg grayscale"
                      />
                      {mediator.verified && (
                        <div className="absolute -top-2 -right-2 bg-yellow-600 rounded-full p-2">
                          <CheckCircle2 className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>
                    <Badge className="bg-black text-white hover:bg-black rounded-none">
                      Online
                    </Badge>
                  </div>
                  
                  <div>
                    <h3 className="text-2xl font-bold text-black mb-2">{mediator.name}</h3>
                    <p className="text-yellow-600 font-semibold mb-3 text-lg">{mediator.specialty}</p>
                    
                    {/* Rating & Location */}
                    <div className="flex items-center gap-6 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-600 text-yellow-600" />
                        <span className="font-semibold text-black">{mediator.rating}</span>
                        <span>({mediator.reviews})</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        <span>{mediator.location}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Details */}
                <div className="p-8 bg-white">
                  <div className="space-y-4 mb-8">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <Clock className="w-4 h-4" />
                        <span>Experience: {mediator.experience}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <Users className="w-4 h-4" />
                        <span>Languages: {mediator.languages.join(", ")}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                      <div className="text-gray-600 text-sm">Starting from</div>
                      <div className="text-3xl font-bold text-yellow-600">${mediator.hourlyRate}/hr</div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <Button className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-4 rounded-none transition-all duration-300 group-hover:shadow-lg flex items-center justify-center gap-2">
                      <Calendar className="w-5 h-5" />
                      Book Consultation
                    </Button>
                    <Button variant="outline" className="w-full border-2 border-black text-black hover:bg-black hover:text-white font-bold py-4 rounded-none transition-all duration-300">
                      View Profile
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredMediators.length === 0 && (
          <div className="text-center py-20">
            <div className="text-6xl mb-6">🔍</div>
            <h3 className="text-3xl font-bold text-black mb-4">No mediators found</h3>
            <p className="text-gray-600 text-lg">Try adjusting your search criteria or browse all available mediators.</p>
          </div>
        )}
      </section>

      {/* Features Section */}
      <section className="bg-black text-white py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-bold mb-6">Why Choose Zenara?</h2>
            <div className="w-24 h-1 bg-yellow-600 mx-auto mb-8"></div>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Professional mediation services with global reach and local expertise
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-20 h-20 bg-yellow-600 flex items-center justify-center mx-auto mb-8">
                <Shield className="w-10 h-10 text-black" />
              </div>
              <h3 className="text-2xl font-bold mb-6">Certified Professionals</h3>
              <p className="text-gray-300 leading-relaxed text-lg">
                All our mediators are certified and have extensive experience in their specialties
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-white flex items-center justify-center mx-auto mb-8">
                <Clock className="w-10 h-10 text-black" />
              </div>
              <h3 className="text-2xl font-bold mb-6">Fast Resolution</h3>
              <p className="text-gray-300 leading-relaxed text-lg">
                Average case resolution time of 30 days compared to years in traditional courts
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-yellow-600 flex items-center justify-center mx-auto mb-8">
                <Users className="w-10 h-10 text-black" />
              </div>
              <h3 className="text-2xl font-bold mb-6">Global Network</h3>
              <p className="text-gray-300 leading-relaxed text-lg">
                Connect with mediators worldwide, supporting multiple languages and jurisdictions
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-24 bg-yellow-600">
        <div className="max-w-4xl mx-auto px-6 text-center text-black">
          <h2 className="text-5xl md:text-6xl font-bold mb-8">
            Ready to Resolve Your Dispute?
          </h2>
          <p className="text-xl mb-12 max-w-2xl mx-auto leading-relaxed">
            Join thousands of satisfied clients who have found resolution through our platform
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button 
              size="lg" 
              className="bg-black text-white hover:bg-gray-800 font-bold py-6 px-12 rounded-none text-lg transition-all duration-300"
            >
              Start Your Case
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-2 border-black text-black hover:bg-black hover:text-white font-bold py-6 px-12 rounded-none text-lg transition-all duration-300"
            >
              Learn More
            </Button>
          </div>
          
          <p className="text-sm text-black/70 mt-8 font-medium">
            Free consultation available • No upfront costs • 100% confidential
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="text-3xl font-bold mb-4">Zenara</div>
          <div className="w-16 h-1 bg-yellow-600 mx-auto mb-6"></div>
          <p className="text-gray-400 mb-8 text-lg">Balanced Resolutions. Global Impact.</p>
          <div className="text-sm text-gray-500">
            © 2025 Zenara. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}